# TGO contextual Markdown draft

Generated from canonical JSONL. The ordering is source order, not a canonical story route. Do not alter record IDs, source hashes, or source blocks. Edit only `TGO-TRANSLATION:` JSON strings. This draft may include `needs_review` material and is not yet approved as a translator delivery package.
