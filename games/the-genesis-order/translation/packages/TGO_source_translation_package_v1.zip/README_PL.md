# The Genesis Order — pakiet źródłowy do tłumaczenia (v1)

## Co zawiera

- Kanoniczne JSONL ze stabilnymi ID, tekstem źródłowym, kontekstem i pustym polem `translation`.
- Kontekstowy Markdown dla map i Common Events; zachowuje gałęzie i kolejność źródłową.
- Glosariusz roboczy, zasady workflow oraz raport zakresu.

To pełny pakiet statycznie wyodrębnionych, potwierdzonych powierzchni tekstu według audytu z 2026-10-29. Nie jest patchem gry i nie zawiera oryginalnych assetów, mediów, zapisów ani kodu gry.

## Jak wprowadzać tłumaczenia

1. W Markdown edytuj wyłącznie wartość po `TGO-TRANSLATION:`. Albo pracuj w JSONL i zmieniaj wyłącznie pole `translation`.
2. Nie zmieniaj `id`, `source_text`, `source`, hashy, locatorów, `context`, `structure` ani `markup_tokens`.
3. Zachowaj wszystkie tokeny/escape’y w `markup_tokens` dokładnie i w tej samej kolejności.
4. Rekordy z `context.translation_policy=keep_source_value` są zablokowane. W pakiecie chronionych jest 131 wartości; pozostaw tłumaczenie puste lub równe źródłu.
5. Przekaż z powrotem komplet zmodyfikowanych plików albo JSONL wraz z ich ID. Nie pomijaj żadnych rekordów tekstu gracza.

## Ważne ograniczenia kontekstu

- Pakiet zawiera **45,229 rekordów** wyeksportowanych według jawnych reguł i coverage checks. Odczytuj kategorię oraz kontekst rekordu; nie każdy widoczny tekst jest dialogiem, a niezweryfikowanych literałów nie klasyfikuj jako UI. Źródłowy język nie został formalnie potwierdzony, choć wiele wpisów wygląda na angielskie. Językiem docelowym projektu jest polski.
- Wszystkie **2 110 opcji** w 695 grupach i **1 513 nie-rendererowych wierszy `401`** są pełnoprawnymi tekstami widocznymi dla gracza i należą do zakresu tłumaczenia (1 122 wiadomości, 378 pozycji UI telefonu, 13 natywnych tekstów telefonu). To zatwierdzona decyzja zakresowa.
- Markdown jest uporządkowany według źródeł, **nie** według kanonicznej chronologii fabuły. Czytaj warunki i branch path z kontekstu.
- Zgodnie z decyzją właściciela tekst wtopiony w obrazy i wideo nie jest tłumaczony. Dynamiczne nazwy urządzeń/użytkowników dostarczane przez runtime również nie są statycznymi stringami gry.

Szczegółowe liczniki i coverage checks są w `docs/COUNT_REPORT.md` oraz `translation/export-v1/export_manifest.json`. Nie uruchamiaj gry na podstawie tego pakietu.
